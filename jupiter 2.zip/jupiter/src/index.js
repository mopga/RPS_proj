import { Select } from '@/js/select'
import { rangeSliderController } from '@/js/slider'

// Test import of styles
import '@/styles/index.scss'

//const app = document.querySelector('#root')
//app.append(logo, heading, imageBackground, imagePublic)

const mobileNavButton = document.querySelector('.mobile-nav-button')
const mobileNavIcon = document.querySelector('.mobile-nav-button__icon')
const mobileNav = document.querySelector('.mobile-nav')

mobileNavButton.addEventListener('click', () => {
  mobileNavIcon.classList.toggle('active')
  mobileNav.classList.toggle('active')
  document.body.classList.toggle('no-scroll')
})

// Custom select
Select()

// Slider
/*
let slider = document.querySelectorAll('.slider-wrapper')
if (slider.length > 0) {
  rangeSliderController('slider')
}
*/

let current,
  test = window.location.pathname.split('/')

if (test.length > 1 && test[1] !== '') {
  current = test[1]
} else {
  current = 'main'
}

// Data-type change
let dataTypeItems = document.querySelectorAll('.data-type li')
if (dataTypeItems.length > 0) {
  dataTypeItems.forEach((item) => {
    item.addEventListener('click', function (e) {
      if (this.classList.contains('selected')) {
        return false
      } else {
        e.stopPropagation()
        document.querySelector('.data-type li.selected').classList.remove('selected')
        this.classList.add('selected')
      }
    })
  })
}

// model-type change
let modelTypeItems = document.querySelectorAll('.model-type .btn')
if (modelTypeItems.length > 0) {
  modelTypeItems.forEach((item) => {
    item.addEventListener('click', function (e) {
      e.preventDefault()
      this.classList.toggle('selected')
      return false
    })
  })
}

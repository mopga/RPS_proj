export const rangeSliderController = (sl) => {
  const slider = document.getElementById(sl + '-js')
  const sliderHandle = document.getElementById(sl + '-handle')
  const sliderCounter = document.getElementById(sl + '-counter')
  const sliderValue = 3
  let sliderOffset = slider.offsetLeft
  let sliderWidth = slider.offsetWidth
  let isMoving = false
  let handlePosition = null
  let valueStops = (function () {
    let array = []
    let fraction = sliderWidth / sliderValue
    for (let i = 0; i <= sliderValue; i++) {
      array.push(fraction * i)
    }
    return array
  })()
  let skipPoint = valueStops[1] / 2

  window.addEventListener('resize', function () {
    isMoving = false
    handlePosition = null
    valueStops = (function () {
      let array = []
      let fraction = sliderWidth / sliderValue
      for (let i = 0; i <= sliderValue; i++) {
        array.push(fraction * i)
      }
      return array
    })()
    skipPoint = valueStops[1] / 2
    sliderOffset = slider.offsetLeft
    sliderWidth = slider.offsetWidth
  })

  slider.addEventListener('mousedown', function (event) {
    event.preventDefault()
    isMoving = true
    handlePosition = event.pageX - sliderOffset
    valueStops.forEach(function (stop, i) {
      if (handlePosition >= stop - skipPoint) {
        sliderHandle.style.left = stop + 'px'
        sliderCounter.style.left = stop + 'px'
        sliderCounter.innerHTML = i + 1
      }
    })
  })

  window.addEventListener('mousemove', function (event) {
    if (isMoving) {
      handlePosition = event.pageX - sliderOffset
      handlePosition = Math.min(Math.max(parseInt(handlePosition), 0), sliderWidth)
      valueStops.forEach(function (stop, i) {
        if (handlePosition >= stop - skipPoint) {
          sliderHandle.style.left = stop + 'px'
          sliderCounter.style.left = stop + 'px'
          sliderCounter.innerHTML = i + 1
        }
      })
    }
  })

  window.addEventListener('mouseup', function (event) {
    isMoving = false
  })
}
